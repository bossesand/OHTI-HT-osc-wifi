
This program need to be run as Administrator on Win10 to allow it to open local IKP port 9000 for listening.